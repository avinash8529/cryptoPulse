import React from 'react';
import './index.css';

const Registration = () => {


    const makeRegistration = (evt) => {
        if (evt && evt.preventDefault) {
            evt.preventDefault()
        }

        const formData = new FormData(evt.target);

        const data = {}
        for (const [key, value] of formData) {
            console.log(key, value)
            data[key] = value;
        }

    }
    return (
        <>
            <div className="login-page">
                <div className="form">
                    <form className="login-form" onSubmit={makeRegistration}>
                        <input type="text" placeholder="name" name="name" />
                        <input type="text" placeholder="username" name="userName" />
                        <input type="text" placeholder="Email" name="email" />
                        <input type="password" placeholder="password" name="password" />
                        <input type="password" placeholder="confirm Password" name="confirmPassword" />
                        <div className="error"></div>
                        <button type='submit'>signup</button>
                        <p className="message">If registered? <a href="http://localhost:3000/login">Go to Login</a></p>
                    </form>
                </div>
            </div>
        </>
    )
}
export default Registration;